
const questions = [
    // BÖLÜM 1: TEMEL (1-10)
    {
        title: "Bölüm 1: Temel Seviye",
        question: "int sonuc = 10 + 5 * 2; işleminin sonucu nedir?",
        code: null,
        options: ["30", "20", "15", "25"],
        correct: 1,
        feedback: "İşlem önceliği çarpmadadır. (5 * 2 = 10, sonra 10 + 10 = 20)"
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "Aşağıdaki döngü kaç kez çalışır?",
        code: "for (int i = 0; i < 5; i++) {\n    // kodlar\n}",
        options: ["4", "5", "6", "Sonsuz"],
        correct: 1,
        feedback: "0'dan başlayıp 5'e kadar (5 hariç) 0,1,2,3,4 olmak üzere 5 kez çalışır."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "17 % 3 işleminin sonucu kaçtır?",
        code: null,
        options: ["1", "2", "3", "5"],
        correct: 1,
        feedback: "Mod operatörü kalanı verir. 17 / 3 işleminden kalan 2'dir."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "int x = 7 / 2; kodundan sonra x'in değeri ne olur?",
        code: null,
        options: ["3.5", "3", "4", "Hata verir"],
        correct: 1,
        feedback: "Tam sayı bölmesinde ondalık kısım atılır."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "Hangi operatör 'Eşit değildir' anlamına gelir?",
        code: null,
        options: ["=", "==", "!=", "!"],
        correct: 2,
        feedback: "!= operatörü iki değerin birbirine eşit olmadığını kontrol eder."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "(true && false) || true ifadesinin sonucu nedir?",
        code: null,
        options: ["true", "false", "null", "Hata"],
        correct: 0,
        feedback: "Parantez içi false olur, (false || true) ise true sonucunu verir."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "Aşağıdaki kod ne yazdırır?",
        code: "int a = 10;\nif (a > 5) {\n    System.out.print(\"A\");\n} else {\n    System.out.print(\"B\");\n}",
        options: ["A", "B", "AB", "Hiçbir şey"],
        correct: 0,
        feedback: "Koşul (10 > 5) doğru olduğu için if bloğu çalışır."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "while döngüsü ne zaman durur?",
        code: null,
        options: ["Koşul true olduğu sürece", "Koşul false olduğunda", "Her zaman 10 kez çalışır", "Sadece break ile"],
        correct: 1,
        feedback: "while döngüsü parantez içindeki koşul yanlış (false) olduğunda durur."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "Bir değişkenin değerini 1 artırmak için hangisi kullanılır?",
        code: null,
        options: ["x+", "+x", "x++", "x = 1"],
        correct: 2,
        feedback: "x++ veya ++x değişkenin değerini 1 artırır."
    },
    {
        title: "Bölüm 1: Temel Seviye",
        question: "switch-case yapısında hiçbir case eşleşmezse hangi blok çalışır?",
        code: null,
        options: ["else", "fallback", "default", "Hiçbiri"],
        correct: 2,
        feedback: "Default bloğu, diğer hiçbir durum eşleşmediğinde çalışır."
    },

    // BÖLÜM 2: ZOR (11-20)
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Aşağıdaki kodun çıktısı nedir?",
        code: "int a = 5;\nint b = a++;\nSystem.out.print(a + \" \" + b);",
        options: ["5 5", "6 6", "6 5", "5 6"],
        correct: 2,
        feedback: "a++ (post-increment) önce değeri b'ye atar, sonra a'yı 1 artırır."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Break kullanılmayan bu switch bloğunda sonuç ne olur?",
        code: "int n = 1;\nswitch(n) {\n  case 1: System.out.print(\"1\");\n  case 2: System.out.print(\"2\");\n  default: System.out.print(\"3\");\n}",
        options: ["1", "12", "123", "Hata"],
        correct: 2,
        feedback: "Break olmadığı için eşleşen case'den sonraki tüm kodlar çalışır (Fall-through)."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Bu iç içe döngü toplamda kaç yıldız (*) yazdırır?",
        code: "for(int i=0; i<3; i++) {\n  for(int j=0; j<2; j++) {\n    System.out.print(\"*\");\n  }\n}",
        options: ["3", "5", "6", "9"],
        correct: 2,
        feedback: "Dıştaki döngü 3, içteki 2 kez döner. 3 * 2 = 6."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Aşağıdaki ifadenin sonucu nedir?",
        code: "boolean x = !(5 == 5) || (3 > 2 && 4 < 1);",
        options: ["true", "false", "Hata", "null"],
        correct: 1,
        feedback: "!(true) = false. (true && false) = false. Sonuç: false || false = false."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Döngü bittiğinde 'toplam' değişkeni kaç olur?",
        code: "int toplam = 0;\nfor(int i=0; i<10; i++) {\n  if(i % 2 == 0) continue;\n  toplam += i;\n}",
        options: ["45", "20", "25", "30"],
        correct: 2,
        feedback: "Continue çift sayıları atlar. Sadece tek sayılar toplanır: 1+3+5+7+9 = 25."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Döngüden çıkıldığında i değeri kaç olur?",
        code: "int i = 0;\nwhile(i < 5) {\n  if(i == 3) break;\n  i++;\n}",
        options: ["3", "4", "5", "0"],
        correct: 0,
        feedback: "i=3 olduğunda break döngüyü o anki değerle aniden sonlandırır."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Aşağıdaki kod bloğu ne yazdırır?",
        code: "int x = 10, y = 20;\nif (x > 5) x = 5;\nif (y > x) y = x;\nSystem.out.print(x + y);",
        options: ["30", "15", "10", "25"],
        correct: 2,
        feedback: "x 5 olur. y > 5 olduğu için y de 5 olur. 5 + 5 = 10."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Hangi döngü yapısı 'sonsuz döngü' oluşturur?",
        code: null,
        options: ["for(;;)", "while(true)", "do{}while(true)", "Hepsi"],
        correct: 3,
        feedback: "Bu üç yapı da herhangi bir çıkış koşulu eklenmezse sonsuza kadar döner."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "int a=2, b=3, c=4; ise a*b+c/a işleminin sonucu nedir?",
        code: null,
        options: ["8", "5", "7", "6"],
        correct: 0,
        feedback: "Önce çarpma (2*3=6) ve bölme (4/2=2) yapılır. 6 + 2 = 8."
    },
    {
        title: "Bölüm 2: İleri Seviye",
        question: "Aşağıdaki kodun çıktısı nedir?",
        code: "int i = 1;\ndo {\n  i *= 2;\n} while (i < 1);\nSystem.out.print(i);",
        options: ["1", "2", "0", "Hata"],
        correct: 1,
        feedback: "do-while en az bir kez çalışır. i=1 iken 2 ile çarpılır, sonra koşul (2 < 1) kontrol edilir."
    }
];

let currentQuestionIndex = 0;
let score = 0;

const questionEl = document.getElementById('question');
const titleEl = document.getElementById('section-title');
const codeEl = document.getElementById('code-container');
const optionsContainer = document.getElementById('options-container');
const feedbackEl = document.getElementById('feedback');
const nextBtn = document.getElementById('next-btn');
const scoreEl = document.getElementById('score');
const progressEl = document.getElementById('progress-bar');

function loadQuestion() {
    const q = questions[currentQuestionIndex];
    titleEl.innerText = q.title;
    questionEl.innerText = q.question;
    feedbackEl.classList.add('hidden');
    nextBtn.classList.add('hidden');
    optionsContainer.innerHTML = '';
    
    progressEl.style.width = ((currentQuestionIndex) / questions.length) * 100 + "%";

    if(q.code) {
        codeEl.classList.remove('hidden');
        codeEl.querySelector('code').innerText = q.code;
    } else {
        codeEl.classList.add('hidden');
    }

    q.options.forEach((opt, index) => {
        const btn = document.createElement('button');
        btn.className = 'option';
        btn.innerText = opt;
        btn.onclick = () => selectOption(index, q.correct, q.feedback);
        optionsContainer.appendChild(btn);
    });
}

function selectOption(index, correctIndex, feedbackText) {
    const allOptions = document.querySelectorAll('.option');
    allOptions.forEach(opt => opt.style.pointerEvents = 'none');

    if(index === correctIndex) {
        allOptions[index].classList.add('correct');
        score++;
        scoreEl.innerText = score;
        feedbackEl.innerText = "✨ Doğru! " + feedbackText;
        feedbackEl.className = "feedback success";
    } else {
        allOptions[index].classList.add('wrong');
        allOptions[correctIndex].classList.add('correct');
        feedbackEl.innerText = "❌ Yanlış! " + feedbackText;
        feedbackEl.className = "feedback error";
    }
    
    feedbackEl.classList.remove('hidden');
    nextBtn.classList.remove('hidden');
}

nextBtn.onclick = () => {
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length) {
        loadQuestion();
    } else {
        showResults();
    }
};

function showResults() {
    progressEl.style.width = "100%";
    const container = document.querySelector('.quiz-card');
    let message = score > 15 ? "Harika iş çıkardın! 🚀" : "Güzel deneme, biraz daha tekrarla mükemmel olacaksın! 💪";
    container.innerHTML = `
        <div style="text-align:center;">
            <h2>Quiz Tamamlandı! 🎉</h2>
            <p style="font-size: 1.2rem; color: #64748b;">${message}</p>
            <p style="font-size: 2rem; font-weight: bold; margin: 20px 0;">${score} / ${questions.length}</p>
            <button class="next-btn" onclick="location.reload()" style="display:block; margin: 20px auto;">Baştan Başla</button>
        </div>
    `;
}

loadQuestion();
